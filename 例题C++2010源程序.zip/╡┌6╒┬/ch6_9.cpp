#include<iostream>
using namespace std;

class TestOperator
{
public:
	TestOperator * operator->()
	{
		return this;
	}
	void setInt(int n)
	{
		num = n;
	}
	int getInt()
	{
		return num;
	}
private:
	int num;
};

int main()
{
	TestOperator object1;
	object1->setInt(10);
	cout<<"object1.getInt() is:  "<<object1.getInt()<<endl;
	cout<<"object1->getInt() is: "<<object1->getInt()<<endl;

	return 0;
}
