// ch6_2_1.cpp
#include<iostream>
using namespace std;

class MyString
{
public:
	MyString(char*str)
	{
		cout<<"constructor with one parameter, char*----->String"<<endl;
		strcpy_s(name,str);
	}
	MyString(MyString &s)
	{
		cout<<"copy constructor"<<endl;
		strcpy_s(name,s.name);
	}
	MyString()
	{
		cout<<"no parameter constructor"<<endl;
	}
	~MyString()
	{
		cout<<"deconstructor"<<endl;
	}
	MyString operator+(const MyString&);
	void operator= (const MyString &s)
	{
		strcpy_s(name,s.name);
		cout<<"operator = "<<endl;
	}
	void display()
	{
		cout<<"The MyString is :"<<name<<endl;
	}
private:
	char name[256];
};

static char* str;

MyString MyString::operator+(const MyString& a)
{
	MyString s;
	cout<<"operator + "<<endl;
	strcpy_s(s.name,name);
	strcat_s(s.name,a.name);
	return s;
}

int main()
{
	str=new char[256];
	MyString demo1("Visual c++");
	MyString demo2("6.0");	
	demo1.display();
	demo2.display();
	MyString demo3;
	demo3 = demo1+demo2;
	cout<<"-------------"<<endl;
	demo3.display();
	MyString demo4;
	demo4 = demo3+" Programming.";
	demo4.display();
	delete str;
	cout<<"-------------"<<endl;
	MyString demo5=demo4;
	demo5.display();

	return 0;
}
