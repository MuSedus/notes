#include<iostream>
using namespace std;

class Rectangle
{
public:
	Rectangle()  { }
	Rectangle(int l,int w)
	{
		length=l;	width=w;
	}
	void disp()
	{
		cout<<length*width<<endl;
	}
	Rectangle operator,(Rectangle r)
	{
		Rectangle temp;
		temp.length =r.length;
		temp.width=r.width;
		return temp;
	}
	Rectangle operator+(Rectangle r)
	{
		Rectangle temp;
		temp.length=r.length+length;
		temp.width=r.width+width;
		return temp;
	}
private:
	int length,width;
};

int main()
{
	Rectangle r1(1,2),r2(3,4),r3(5,6);
	cout<<"r1�����Ϊ��";	r1.disp();
	cout<<"r2�����Ϊ��";	r2.disp();
	cout<<"r3�����Ϊ��";	r3.disp();
	cout<<"(r1, r2+r3, r3)�����Ϊ��";	(r1, r2+r3, r3).disp();
	cout<<"(r1, r3, r2+r3)�����Ϊ��";	(r1, r3, r2+r3).disp();

	return 0;
}
