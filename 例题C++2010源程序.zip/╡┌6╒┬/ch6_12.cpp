#include <string>
#include <iostream>
using namespace std;

class Name
{
public:
	Name(){ pName = 0; }
	Name(char* pn){ copyName(pn); }
	~Name(){ deleteName(); }
	Name & operator =(Name & s)		// ���ظ�ֵ�����
	{
		deleteName();
		copyName(s.pName);
		return *this;
	}
	void display(){ cout << pName << endl; }
protected:
	void copyName(char* pN);
	void deleteName();
	char* pName;
};

void Name::copyName(char* pN)
{
	pName = new char[strlen(pN) + 1];
	if(pName)
		strcpy_s(pName,strlen(pN) + 1,pN);
}

void Name::deleteName()
{
	if(pName)
	{
		delete pName;
		pName = 0;
	}
}

int main()
{
	Name s("Jone");
	Name t("temporary");
	t.display();
	t = s;                        // ����ֵ
	t.display();

	return 0;
}
