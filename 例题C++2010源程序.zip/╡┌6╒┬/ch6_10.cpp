#include<iostream>
using namespace std;

class Sample
{
public:
	Sample( ) { }
	Sample(int i) 
	{
		num=i;
	}
	Sample& operator=(Sample);
	void disp( )
	{
		cout<<"num = "<<num<<endl;
	}
private:
	int num;
};

Sample& Sample::operator=(Sample s)
{
	Sample::num=s.num;
	return *this;
}

int main()
{
	Sample s1(10),s2;
	s2=s1;
	s2.disp( );

	return 0;
}
