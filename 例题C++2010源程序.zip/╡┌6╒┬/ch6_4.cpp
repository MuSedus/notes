#include<iostream>
using namespace std;

class MyString
{  
public:
	MyString(char* str)
	{
		strcpy_s(name,str);
	}
	MyString(){ }
	~MyString(){ }
	friend MyString operator+(const MyString&, const MyString&);
	void display()
	{
		cout<<"The MyString is :"<<name<<endl;
	}
private:
	char name[256];
};

static char* str;

MyString operator+(const MyString& a,const MyString& b)
{ 
	strcpy_s(str,strlen(a.name)+1,a.name);
	strcat_s(str,strlen(str)+strlen(b.name)+1,b.name);
	return MyString(str);
}

int main()
{ 
	str=new char[256];
	MyString demo1("Visual c++");
	MyString demo2(" 6.0");
	demo1.display();
	demo2.display();
	MyString demo3=demo1+demo2;
	demo3.display();
	MyString demo4=demo3+" Programming.";
	demo4.display();
	MyString demo5="Programming. "+demo4;
	demo5.display();
	delete str;

	return 0;
}
