#include<iostream>
using namespace std;

class Complex
{
public:
	Complex(float r=0,float i=0)
	{	real=r;	imag=i;	}
	void print();
	friend Complex operator +(Complex a,Complex b);
	friend Complex operator -(Complex a,Complex b);
	friend Complex operator *(Complex a,Complex b);
	friend Complex operator /(Complex a,Complex b);
private:
	float real,imag; 		// ������ʵ�����鲿
};

void Complex::print()
{
	cout<<real;
	if(imag>0) cout<<"+";			// imageС��0�����Դ�-
	if(imag!=0) cout<<imag<<"i\n";
}

Complex operator+(Complex a,Complex b)
{
	Complex temp;
	temp.real=a.real+b.real;
	temp.imag=a.imag+b.imag;

	return temp;
}

Complex operator-(Complex a,Complex b)
{
	Complex temp;
	temp.real=a.real-b.real;
	temp.imag=a.imag-b.imag;

	return temp;
}

Complex operator*(Complex a,Complex b)
{
	Complex temp;
	temp.real=a.real*b.real-a.imag*b.imag;
	temp.imag=a.real*b.imag+a.imag*b.real;

	return temp;
}

Complex operator/(Complex a,Complex b)
{
	Complex temp;
	float tt;
	tt=1/(b.real*b.real+b.imag*b.imag);
	temp.real=(a.real*b.real+a.imag*b.imag)*tt;
	temp.imag=(b.real*a.imag-a.real*b.imag)*tt;

	return temp;
}

int main()
{
	Complex c1(2.3f,4.6f),c2(3.6f,2.8f),c3;
	cout<<"c1:	";	c1.print();
	cout<<"c2:	";	c2.print();
	c3=c1+c2;
	cout<<"c1+c2:	";	c3.print();
	c3=c1-c2;
	cout<<"c1-c2:	";	c3.print();
	c3=c1*c2;
	cout<<"c1*c2:	";	c3.print();
	c3=c1/c2;
	cout<<"c1/c2:	";	c3.print();

	return 0;
}
