#include<iostream>
using namespace std;

class MyString
{
public:
	MyString(char*str)
	{
		strcpy_s(name,str);
	} 
	MyString() { }
	~MyString(){ }
	MyString operator+(const MyString&);
	void display()
	{
		cout<<"The MyString is :"<<name<<endl;
	}
private:
	char name[256];
};

static char* str;

MyString MyString::operator+(const MyString& a)
{
	strcpy_s(str,strlen(name)+1,name);
	strcat_s(str,strlen(str)+strlen(a.name)+1,a.name);//ע��ڶ���������Ŀ�껺�������ܴ�С
	return MyString(str);
}

int main()
{
	str=new char[256];
	MyString demo1("Visual c++");
	MyString demo2("6.0");	
	demo1.display();
	demo2.display();
	MyString demo3=demo1+demo2;
	demo3.display();
	MyString demo4=demo3+" Programming.";
	demo4.display();
	delete str;

	return 0;
}
