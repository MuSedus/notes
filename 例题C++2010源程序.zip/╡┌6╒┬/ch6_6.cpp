#include<iostream>
using namespace std;

class  Student
{
public:
	void operator[] (Student&);	// ��ÿ��ѧ����ƽ����
	Student (char *na,float ma=0,float en=0,float ph=0)
	{
		score[0]=ma; score[1]=en; score[2]=ph; strcpy_s(name,na);
	}
	void  operator !()		// ������ѧ�����ſε�ƽ���ɼ�
	{
		if(sum>0) 
			cout<<"Mat:"<<score[0]/sum
				<<"	Eng:"<<score[1]/sum
				<<"	Phy:"<<score[2]/sum<<endl; 
	}
private:
	char  name[10];
	float  score[3];
	static  unsigned  int  sum;	// ��̬��Աsum��ʾ�μӼ����ѧ���ɼ�
};

void  Student::operator[] (Student &s)
{
	unsigned  int  i;
	float  nt = 0.;
	for(i=0;i<3;i++)
	{
		score[i]+=s.score[i];
		nt+=s .score[i];
	}
	cout<<s.name<<":	"<<nt/3<<endl;
	sum++;
}

unsigned  int  Student::sum = 0;

int main()
{
	int  i ;
	Student  sa[]={Student("Wang",60,70,80),
	Student("Li",70,80,90),
	Student("Zhang",50,60,70)},total("Total");
	for(i=0;i<3;i++)
		total[sa[i]];
	!total;

	return 0;
}
