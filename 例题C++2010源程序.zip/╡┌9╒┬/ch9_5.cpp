#include<iostream>
#include<afxcoll.h>
using namespace std;

int main()
{
	CArray<wchar_t,int> m_array;
	CStringArray m_strArray;
	m_strArray.SetSize(5);
	m_strArray[0] = "zhao";
	m_strArray[2] = "sun";
	m_strArray[4] = "zhou";
	m_strArray.Add("wu");
	m_strArray.SetAt(1,"qian");
	for(int i=0;i<m_strArray.GetSize();i++)
		wcout<<m_strArray[i].GetString()<<endl;

	return 0;
}
