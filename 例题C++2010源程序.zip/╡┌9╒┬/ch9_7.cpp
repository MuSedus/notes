#include <iostream>
#include <afx.h>
#include <string.h>
using namespace std;

class Student 
{
public:
	char m_strName[10];
	char m_Sex[6];
	int	 m_nAge;
	char m_strDept[20];
	float  m_math;
	Student() { }
	Student(char *name,char *sex,int age,char *dept,float math);
	void SaveStudent(CFile* fp) { fp->Write(this,sizeof(Student));}
	void ReadStudent(CFile* fp) { fp->Read(this,sizeof(Student)); }
	void ShowMe() {
		cout<<m_strName<<"\t"<<m_Sex<<"\t"<<m_nAge<<"\t";
		cout<<m_strDept<<"\t"<<m_math<<endl;
	}
};

Student::Student(char *name,char *sex,int age,char *dept,float salary)
{
	strcpy_s(m_strName, name);
	strcpy_s(m_Sex , sex );
	m_nAge = age;
	strcpy_s(m_strDept, dept);
	m_math = salary;
}

int main()
{
	int count=0;
	Student stu[50];
	int i,j,age;
	float salary;
	CFile myfile;
	CFileException e;
	char name[10],sex[6],dept[20];
	for(;;)
	{
		cout<<" 1.��ʾ���� 2.����ѧ�� 3.ɾ��ѧ��";
		cout<<" 4.�洢��Ϣ 5.��ȡ��Ϣ 6.�˳�\n";
		cout<<"������ѡ���ţ�";
		cin>>i;
		switch(i) {
		case 1: 
			cout<<endl<<"-------------------------------------------------------"<<endl;
			for(i=0;i<count;i++) { 
				cout<<" "<<i+1<<"\t"; 
				stu[i].ShowMe(); 
			}
			cout<<"-------------------------------------------------------"<<endl<<endl;
			break;
		case 2: 
			if(count<50) {
				i=count++;
				cout<<"�����������������Ա����䡢����ϵ������ѧ�ɼ�:\n";
				cin>>name>>sex>>age>>dept>>salary;
				stu[i]=Student(name,sex,age,dept,salary);
				strcpy_s(stu[i].m_strDept, dept);
				stu[i].m_math = salary;
			}
			else { cout<<"�洢�ռ�����"; }
			break;
		case 3:
			cout<<"����Ҫɾ����ѧ����:\t";
			cin>>i;
			if(i<=count && i>0) {
				for(j= i; j< count; j++) { stu[j-1]=stu[j]; }
				count--;
				cout<<"\n  ---  ��¼��ɾ��  ---\n\n";
			}
			else { cout<<"�������"; }
			break;
		case 4:
			myfile.Open(_T("emp_Rec"),CFile::modeWrite|CFile::modeCreate,&e);
			myfile.Write(&count,sizeof(count));
			for(j=0;j<count;j++) stu[j].SaveStudent(&myfile);
			myfile.Close();
			cout<<"\n    --- ѧ����Ϣ�ѱ��� ---   \n\n";
			break;
		case 5:
			if(myfile.Open(_T("emp_Rec"),CFile::modeRead,&e))
			{ 
				myfile.Read(&count,sizeof(count));
				for(j=0;j<count;j++) stu[j].ReadStudent(&myfile);
				myfile.Close();
				cout<<"\n    --- ѧ����Ϣ�Ѷ��� ---   \n\n";
			}
			else {  cout<<"\n  -- �ļ���ʧ�� -- \n\n"; } 
			break;
		default:  
			return 0;
		}


	}
	return 0;
}
