// ch4_7.cpp
#include<iostream>
using namespace std;

class Complex
{
public:
	Complex(double r = 0, double i = 0)
	{
		real = r; image = i;
	}
	friend void inputcomplex(Complex &comp);
	friend Complex addcomplex(Complex &c1, Complex &c2);
    friend Complex subcomplex(Complex &c1, Complex &c2);
	friend Complex mulcomplex(Complex &c1, Complex &c2);
	friend void outputcomplex(Complex &comp);
private:
	double real;
	double image;
};

void inputcomplex(Complex &comp)
{
	cin >> comp.real >> comp.image;
}

Complex addcomplex(Complex &c1, Complex &c2)
{
	Complex c;
	c.real = c1.real + c2.real;
	c.image = c1.image + c2.image;
	return c;
}

Complex subcomplex(Complex &c1, Complex &c2)
{
	Complex c;
	c.real = c1.real - c2.real;
	c.image = c1.image - c2.image;
	return c;
}

Complex mulcomplex(Complex &c1, Complex &c2)
{
	Complex c;
	c.real = c1.real * c2.real - c1.image * c2.image;
	c.image = c1.real * c2.image + c1.image * c2.real;
	return c;
}

void outputcomplex(Complex &comp)
{
	cout << "(" << comp.real << "," << comp.image << ")";
}

int main()
{
	Complex c1,c2,result;
	cout<<"�������һ��������ʵ�����鲿:"<<endl;
	inputcomplex(c1);
	cout<<"������ڶ���������ʵ�����鲿:"<<endl;
	inputcomplex(c2);
	result=addcomplex(c1,c2);
	outputcomplex(c1);
	cout<<"+";
	outputcomplex(c2);
	cout<<"=";
	outputcomplex(result);
	cout<<"\n-------------------------"<<endl;
	result=subcomplex(c1,c2);
	outputcomplex(c1);
	cout<<"-";
	outputcomplex(c2);
	cout<<"=";
	outputcomplex(result);
	cout<<"\n-------------------------"<<endl;
	result=mulcomplex(c1,c2);
	outputcomplex(c1);
	cout<<"*";
	outputcomplex(c2);
	cout<<"=";
	outputcomplex(result);
	cout<<endl;

	return 0;
}
