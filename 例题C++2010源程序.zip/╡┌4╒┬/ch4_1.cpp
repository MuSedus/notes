// ch4_1.cpp
#include<iostream>
#include<string>
using namespace std;

class  Student
{
public:
	Student(char*s1,char*s2)
	{
		strcpy_s(name,s1);
		strcpy_s(num,s2);
	}
	void display()
	{
		cout<<"Name:"<<name<<endl
			<<"Number:"<<num<<endl;
	}
private:
	char name[10],num[15];
};

class Score
{	
public:
	Score(unsigned int i1,unsigned  int i2,unsigned int  i3)
:mat(i1),phy(i2),eng(i3)
	{   }
	void  displayScore()
	{
		cout<<"Mathematics:"<<mat
			<<"\nPhyics:"<<phy
			<<"\nEnglish:"<<eng<<endl;
	}
private:
	unsigned int mat,phy,eng;
};

int main()
{
	Student  student1("Wang","20163030101");
	Score  score1(72,82,92);
	student1.display();
	score1.displayScore();

	return 0;
}