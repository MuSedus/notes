// ch4_4.cpp
#include<iostream>
using namespace std;

class  Student;		    // �������õ�����
class  Score
{
public:
	Score(unsigned int i1,unsigned int i2,unsigned int i3):mat(i1),phy(i2),eng(i3){}
	void  show()
	{
		cout<<"Mathematics:"<<mat
			<<"\nPhyics:"<<phy
			<<"\nEnglish:"<<eng<<endl;
	}
	void  show(Student&);
private:
	unsigned  int  mat,phy,eng;
};

class Student
{
public:
	Student(char *s1,char *s2)
	{
		strcpy_s(name,s1);
		strcpy_s(num,s2);
	}
	friend void Score::show(Student&);      // ������Ԫ��Ա
private:
	char name[10],num[10];
};

void  Score::show(Student&  st)
{
	cout<<"Name:"<<st.name<<"\n";
	show();
}

int main()
{
	Student  wang("Wang","9901");
	Score  ss(72,82,92);
	ss.show(wang);

	return 0;
}
