// ch4_2.cpp
#include<iostream>
#include<string>
using namespace std;

class  Student
{
public:
	Student(char  *s1,char  *s2)
	{strcpy_s(name,s1);strcpy_s(num,s2);}
private:
	char name[10],num[10];
	friend void	show(Student& st)          // ��Ԫ�����������Ͷ���
	{
		cout<<"Name:"<<st.name<<endl<<"Number:"<<st.num<<endl;
	}
};
class  Score
{
public:
	Score(unsigned  int  i1,unsigned int  i2,unsigned  int i3)
		:mat(i1),phy(i2),eng(i3)
	{  }
private:
	unsigned  int  mat,phy,eng;
	friend  void  show_all(Student&,Score*);     // ��Ԫ����������
};

void  show_all(Student&	st,Score*  sc)       // ��Ԫ�����Ķ���
{
	show(st);
	cout<<"Mathematics:"<<sc->mat
		<<"\nPhyics:"<<sc->phy
		<<"\nEnglish:"<<sc->eng<<endl;
}
int main()
{
	Student  wang("Wang","9901");
	Score  ss(72,82,92);
	show_all(wang,&ss);

	return 0;
}