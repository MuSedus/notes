// ch3_4.cpp
#include "Tdate.h"

int main()
{
	Tdate a,b,c,d;
	a.set(4,12,1996);
	b.set(3);
	c.set(8,10);
	d.set();
	a.print();
	b.print();
	c.print();
	d.print();

	return 0;
}
