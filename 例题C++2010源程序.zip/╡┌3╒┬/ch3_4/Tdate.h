// Tdate.h
#include <iostream>
using namespace std;

class Tdate
{
public:
	void set(int m=5,int d=16,int y=1990)		// ������ֵ
	{
		month=m; day=d; year=y;
	}
	void print()		// �������ֵ
	{
		cout<<month<<"/"<<day<<"/"<<year<<endl;
	}
private:
	int month;
	int day;
	int year;
};
