// ch3_9.cpp
#include<iostream>
#include <string>
using namespace std;

class Student
{
public:
	Student(char* pName)
	{
		cout<<"call one parameter constructor"<<endl;
		strncpy_s(name,pName,sizeof(name));
		name[sizeof(name)-1]= '\0';
		cout<<"the name is "<<name<<endl;
	}
	Student(){cout<<"call no parameter constructor"<<endl;}  
	void display()
	{
		cout<<"the name of the student is "<<name<<endl;
	}
protected:
	char name[20];
};

int main()
{
	static Student noName1;  
	Student noName2;
	Student ss("Jenny");  
	noName1.display();
	noName2.display();
	return 0;
}
