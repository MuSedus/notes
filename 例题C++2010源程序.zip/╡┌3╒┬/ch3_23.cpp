//ch3_23.cpp
#include<iostream>
using namespace std;

class  A
{
public:
	int set(int k)
	{
		i=++k;
		return i;
	}
private:
	int i;
};

int main()
{
	int  (A::*f)(int)=&A::set;
	A  aa;
	cout<<(aa.*f)(10)<<endl;       // ���Ų���ʡ��

	return 0;
}