// ch3_11.cpp
#include<iostream>
using namespace std;

class Test
{
private:
	int num;
	float f1;
public:
	Test(int n);
	Test(int n, float f);   
};

Test::Test(int n)
{
	num = n;
	cout<<"Initializing "<<num<<endl;
}
Test::Test(int n, float f)
{
	num = n;
	f1 = f;
	cout<<"Initializing "<<num<<", "<<f1<<endl;
}

int main()
{
	Test array1[3] = {1,2,3};
	cout<<"-----------------"<<endl;
	Test array2[] = {Test(2,3.5),Test(4)};
	cout<<"-----------------"<<endl;
	Test array3[] = {Test(5.5,6.5),Test(7,8.5)};
	// array3��2��Ԫ��
	cout<<"-----------------"<<endl;
	Test array4[] = {Test(5.5, 6.5), 7.5, 8.5};
	// array4��3��Ԫ��

	return 0;
}
