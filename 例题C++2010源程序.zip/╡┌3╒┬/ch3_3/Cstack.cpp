// Cstack.cpp
#include "Cstack.h"
#include <iostream>
using namespace std;

Cstack::Cstack(void)
{
}

Cstack::~Cstack(void)
{
}

void Cstack::init()
{
	position = 0;
}

char Cstack::push(char ch)
{
	if(position == SIZE)
	{
		cout<<"\nջ���� \n";
		return 0;
	}
	stk[position++] = ch;
	return  ch;
}

char Cstack::pop()
{
	if (position == 0)
	{
		cout<<"\nջ�ѿ�"<<endl;
		return 0;
	}
	return stk[--position];
}

