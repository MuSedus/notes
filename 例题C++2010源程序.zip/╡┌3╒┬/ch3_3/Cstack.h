// Cstack.h
#pragma once

const int SIZE = 10;	// �洢������ַ���

class Cstack
{
public:
	Cstack(void);
	~Cstack(void);
	void init();
	char  push (char ch);
	char  pop();
private:
	char stk[SIZE];
	int  position;
};
