//Test.cpp
#include "Test.h"
#include <iostream>
using namespace std;

Test::Test(void)
{ 
	num = 0;
	f1 = 0.0;
	cout<<"Initializing default"<<endl;
}

Test::Test(int n, float f)
{
	num = n;
	f1 = f;
	cout<<"Initializing "<<num<<", "<<f1<<endl;
}

int Test::getInt()
{return num;}

float Test::getFloat()
{return f1;}

Test::~Test(void)
{
}
