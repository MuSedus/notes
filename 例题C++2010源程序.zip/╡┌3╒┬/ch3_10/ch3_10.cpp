// ch3_10.cpp
#include "Test.h"
#include<iostream>
using namespace std;

int main()
{
	cout<<"the main function:"<<endl;
	Test array[5];
	cout<<"the second element of array is "<<array[1].getInt()
		<<"   "<<array[1].getFloat()<<endl;

	return 0;
}
