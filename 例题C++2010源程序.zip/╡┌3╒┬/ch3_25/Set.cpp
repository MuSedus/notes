// Set.cpp
#include "Set.h"
#include <iostream>
using namespace std;

Set::Set(void)
{
}

Set::~Set(void)
{
}

Bool Set::Member(int elem)
{
	for(int i=0;i<card;++i)
		if(elems[i] == elem)
			return True;
	return False;
}

ErrCode Set::AddElem(int elem)
{
	if(Member(elem))
		return noErr;
	if(card < maxCard)
	{
		elems[card++] = elem;
		return noErr; 
	}
	return overflow;
}

void Set::RmvElem(int elem)
{
	for(int i = 0; i<card; ++i)
		if(elems[i] == elem)
		{
			for(;i<card-1;++i)
				elems[i] = elems[i+1];
			--card;
	        return;
		}
}

void Set::Copy(Set *set)
{
	for(int i = 0; i < card; ++i)
		set->elems[i] = elems[i];
	set->card = card;
}

Bool Set::Equal(Set *set)
{
	if(card != set->card)
		return False;
	for(int i = 0; i < card;++i) 
		// �жϵ�ǰ���ϵ�ĳԪ���Ƿ���set��ָ�����е�Ԫ��
		if(!set->Member(elems[i])) 
			return False;
	return True;
}

void Set::Print( )
{
	cout<<"{";
	for(int i = 0; i < card; ++i)
		cout << elems[i]<< ";";
	cout<<"}\n";
}

void Set::Intersect(Set *set, Set *res)// ������*this��*set->*res
{
	res->card = 0;
	for(int i = 0; i < card; ++i)
		for(int j = 0; j < set->card; ++j)
			if(elems[i] == set->elems[j]){
				res->elems[res->card++] = elems[i];
				break;
			}
}

ErrCode Set::Union(Set *set,Set *res) // ������*set��*this->*res
{
	set->Copy(res);
	for(int i = 0; i < card; ++i)
		if(res->AddElem(elems[i]) == overflow)
			return overflow;
    return noErr;
}