// ch3_24.cpp
#include<iostream>
using namespace std;

class A
{
public:
	static void set(int k)
	{
		i=k;i++;
	}
private:
	static int i;
	friend class B;
};

class B
{
public:
	static void ds(int l)
	{
		int *p=&A::i;
		cout<<*p<<endl;
		*p=l;cout<<*p<<endl;
	}
};

int  A::i=0;
void  (*f1)(int)=&A::set;
void  (*f2)(int)=&B::ds;

int main()
{
	f1(10);
	f2(20);

	return 0;
}
