// MyQueue.cpp
#include "MyQueue.h"
#include <iostream>
using namespace std;

MyQueue::MyQueue(void)
{
	sloc=rloc=0;
	cout<< "queue initialized\n";
}

MyQueue::~MyQueue(void)
{
}

void MyQueue::qput(int i)
{
	if(sloc == 100)
	{
		cout<< "queue is full\n";
		return;
	}
	sloc++;
	q[sloc]=i ;
}

int MyQueue::qget( )
{
	if(rloc==sloc)
	{
		cout<< "queue is empty\n";
		return 0;
	}
	rloc++;
	return q[rloc];
}
