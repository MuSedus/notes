// MyQueue.h
#pragma once
class MyQueue
{
public:
	MyQueue(void);
	~MyQueue(void);
	void qput(int i );
	int qget( );
private:
	int q[100];
	int sloc,rloc;
};

