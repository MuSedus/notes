// ch3_6.cpp
#include "MyQueue.h"
#include <iostream>
using namespace std;

int main()
{
	MyQueue a,b;
	a.qput(10);
	b.qput(20);
	a.qput(20);
	b.qput(19);
	cout<<a.qget( )<< "   ";
	cout<<a.qget( )<< "\n";
	cout<<b.qget( )<< "   ";
	cout<<b.qget( )<< "\n";
	return 0;
}
