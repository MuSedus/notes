//ch3_17.cpp
#include<iostream>
using namespace std;

class Student			// ѧ����Ķ���
{
public:
	Student()
	{
		cout<<"constructing student."<<endl;
		semesHours=100;
		gpa=3.5;
	}
	~Student()
	{
		cout<<"destructing student."<<endl;
	}
protected:
	int semesHours;
	float gpa;
};

class Teacher			// ��ʦ��Ķ���
{
public:
	Teacher()
	{
		cout<<"constructing teacher.\n";
	}
	~Teacher()
	{
		cout<<"destructing teacher.\n";
	}
};

class Tutorpair			// �����Ķ���
{
public:
	Tutorpair()
	{
		cout<<"constructing tutorpair."<<endl;
		nomeeting=0;
	}
	~Tutorpair()
	{
		cout<<"destructing tutorpair."<<endl;
	}
protected:
	Student student;
	Teacher teacher;
	int nomeeting;			// ����ʱ��
};

int main()
{
	Tutorpair tp;
	cout<<"------back to main function.------"<<endl;

	return 0;
}
