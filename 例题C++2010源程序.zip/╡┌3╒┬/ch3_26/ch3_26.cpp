// ch3_26.cpp
#include"Set.h"
#include<iostream>
using namespace std;

int main( )
{
	Set s1, s2, s3;
	s1.AddElem(10);
	s1.AddElem(20);
	s1.AddElem(30); 	
	s1.AddElem(40);
	s2.AddElem(30);
	s2.AddElem(50);
	s2.AddElem(10);
	s2.AddElem(60);
	cout<<"s1="; 	s1.Print( );
	cout<<"s2=";	s2.Print( );
	s2.RmvElem(50);
	cout<<"s2-{50}=";	s2.Print( );
	if(s1.Member(20))
		cout<<"20 is in s1\n";
	s1.Intersect(&s2,&s3);
	cout<<"s1 intsec s2 =";	s3.Print( );
	s1.Union(&s2,&s3);
	cout<<"s1 union s2 =";		s3.Print( );
	if(!s1.Equal(&s2))
		cout<<"s1!=s2\n";
	return 0;
}
