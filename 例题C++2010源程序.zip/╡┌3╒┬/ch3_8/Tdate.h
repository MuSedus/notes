// Tdate.h
#pragma once
class Tdate
{
public:
	Tdate(int m=5,int d=16,int y=1990);	
	~Tdate(void);
private:
	int month;
	int day;
	int year;
};
