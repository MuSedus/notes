// ch3_8.cpp
#include "Tdate.h"

int main()
{
	Tdate aday;
	Tdate bday(2);
	Tdate cday(3,12);
	Tdate dday(1,2,1998);
	return 0;
}
