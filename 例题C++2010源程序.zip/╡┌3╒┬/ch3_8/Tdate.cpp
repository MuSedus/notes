// Tdate.cpp
#include "Tdate.h"
#include <iostream>
using namespace std;

Tdate::Tdate(int m,int d,int y)
{
	month=m;  day=d;  year=y;
	cout <<month <<"/" <<day <<"/" <<year <<endl;
}



Tdate::~Tdate(void)
{
}
