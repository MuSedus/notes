// ch3_20.cpp
#include <iostream>
#include "Student.h"
using namespace std;

Student* fn()
{
	cout<<"------In fn()------"<<endl;
	Student* p =new Student("Jenny");
	Student s3("Jone");
	return p;
}

int main()
{
	Student s1("Jamsa");
	Student* ps =fn();
	cout<<"------Back to main()------"<<endl;
	Student s2("Tracey");
	delete ps;

	return 0;
}
