// Student.h
#pragma once
class Student
{
public:
	Student(void);
	~Student(void);
	Student(char* pName);
protected:
	static Student* pFirst;
	Student* pNext;
	char name[40];
};
