#include<iostream>
using namespace std;

class OBJ1
{
public:
	OBJ1()
	{	cout<<"Constructing OBJ1"<<endl;	}
	~OBJ1()
	{	cout<<"Destructing OBJ1"<<endl;	}
};

class OBJ2
{
public:
	OBJ2()
	{	cout<<"Constructing OBJ2"<<endl;	}
	~OBJ2()
	{	cout<<"Destructing OBJ2"<<endl;	}
};

class Base1
{
public:
	Base1()
	{	cout<<"Constructing Base1"<<endl;	}
	~Base1()
	{	cout<<"destructing Base1"<<endl;	}
};

class Base2
{
public:
	Base2()
	{	cout<<"Constructing Base2"<<endl;	}
	~Base2()
	{	cout<<"Destructing Base2"<<endl;	}
};

class Base3
{
public:
	Base3()
	{	cout<<"Constructing Base3"<<endl;	}
	~Base3()
	{	cout<<"Destructing Base3"<<endl;	}
};

class Base4{
public:
	Base4()
	{	cout<<"Constructing Base4"<<endl;	}
	~Base4()
	{	cout<<"Destructing Base4"<<endl;	}
};

class Derive:public Base1,virtual public Base2,public Base3,virtual public Base4
{
public:
	Derive():Base4(),Base3(),Base2(),Base1(),obj2(),obj1()
	{
		cout <<"Constructing Derive"<<endl ;
	}
	~Derive()
	{	cout<<"Destructing Derive"<<endl;	}
protected:
	OBJ1 obj1;
	OBJ2 obj2;
};

int main()
{
	Derive deriveObject;
	cout<<"----------------------"<<endl;

	return 0;
}
