#include<iostream>
using namespace std;

class Person
{
public:
	Person()
	{	cout<<"the constructor of class Person!\n";	}
	~Person()
	{	cout<<"the destructor of class Person!\n";	}
private:
	char *name;
	int age;
	char*address;
};

class Student:public Person
{
public:
	Student()
	{cout<<"the constructor of class Student!\n";}
	~Student()
	{cout<<"the destructor of class Student!\n";}
private:
	char *department;
	int level;
};

class Teacher:public Person
{
public:
	Teacher()
	{	cout<<"the constructor of class Teacher!\n";	}
	~Teacher()
	{	cout<<"the destructor of class Teacher!\n";	}
private:
	char *major;
	float salary;
};

int main()
{
	Student student1;
	Teacher teacher1;
	cout<<"------main function finished------"<<endl;

	return 0;
}