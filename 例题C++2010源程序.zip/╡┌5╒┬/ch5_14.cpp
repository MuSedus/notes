#include <iostream>
using namespace std;

class Person
{
public:
	Person(char *name,int age,char sex)
	{
		strcpy_s(m_strName, name);
		m_nSex= (sex=='m'?0:1 );
		m_nAge = age;
	}
	void ShowMe()
	{
		cout<<"  ��    ����"<<m_strName<<endl;
		cout<<"  ��    ��"<<(m_nSex==0?"��":"Ů")<<endl;
		cout<<"  ��    �䣺"<<m_nAge<<endl;
	}
protected:
	char m_strName[20];
	int m_nSex;
	int m_nAge;
};

class Teacher: public Person
{
public:
	Teacher(char *name,int age,char sex,char *dept,int salary)
		:Person(name,age,sex)
	{
		strcpy_s(m_strDept, dept);
		m_fSalary = salary;
	}
	void ShowMe() 
	{
		Person::ShowMe();
		cout<<"  ������λ��"<<m_strDept<<endl;
		cout<<"  ��    н��"<<m_fSalary<<endl;
	}
private:
	char m_strDept[30];
	int  m_fSalary;
};

class Student: public Person
{
public:
	Student(char *name,int age,char sex,char *ID,char *Class)
		:Person(name,age,sex)
	{
		strcpy_s(m_strID, ID);
		strcpy_s(m_strClass, Class);
	}
	void ShowMe()
	{
		cout<<"  ѧ    �ţ�"<<m_strID<<endl;
		Person::ShowMe();
		cout<<"  ��    ����"<<m_strClass<<"\n";
	}
private:
	char m_strID[12];
	char m_strClass[50];
};

int main()
{
	Teacher teacher1("��ǿ",38,'m',"��Ϣ����ѧԺ",3800);
	Student student1("����",20,'f',"03016003","�ƿ�173");
	cout<<"------��ʦ��Ϣ���£�------"<<endl;
	teacher1.ShowMe();
	cout<<"------ѧ����Ϣ���£�------"<<endl;
	student1.ShowMe();

	return 0;
}
