#include<iostream>
using namespace std;

template<class T>			// ������ģ��
class List
{
public:
	List();
	void addNode(T&);		// ���ӽ��
	void removeNode(T&);	// ɾ�����
	T* findNode(T&);		// ���ҽ��
	void printList();		// ��ӡ������������ֵ
	~List();
protected:
	struct  Node
	{
		Node* pNext;
		T* Pt;
	};
	Node*  pFirst;
};

template<class T>
List<T>::List()
{
	pFirst=0;
}
     
template<class T>
void List<T>::addNode(T& t)
{
	Node* temp = new Node;
	temp->Pt =&t;
	temp->pNext = pFirst;
	pFirst = temp;
}
 
template<class T>
void List<T>::removeNode(T&t)
{
	Node *q=0;
	if(*pFirst->Pt==t)      
	{
		q=pFirst;
		pFirst=pFirst->pNext;
	}
	else
	{
		for(Node*p=pFirst;p->pNext;p=p->pNext)
			if(*(p->pNext->Pt)==t)
			{
				q=p->pNext;
				p->pNext=q->pNext;
				break;
			}
	}
	if(q)
	{
		cout<<"delete node of value "<<t<<endl;
		delete q->Pt;
		delete q;
	}
	else
		cout<<"In removeNode function: No node of value "<<t<<endl;
}

template<class T>
T*  List<T>::findNode(T& t)
{
	for(Node* p=pFirst;p;p=p->pNext)
	{
		if(*(p->Pt)==t)
			return p->Pt;
	}
	return  0;
}

template<class T>
void List<T>::printList()
{
	cout<<"�����и����ֵΪ��";
	for(Node* p=pFirst;p;p=p->pNext)
	{
		if(p!=pFirst)
			cout<<"->";
		cout<<*(p->Pt);  
	}
	cout<<endl;
}

template<class T>
List<T>::~List()
{	
	Node* p=pFirst;
	while (p)
	{
		pFirst=pFirst->pNext;
		delete p->Pt;
		delete p;
		p=pFirst;
	}
}

int main()
{
	List<int> intList;		// intList��ģ����List<int>�Ķ���
	for(int i=1;i<7;i++)
	{
		intList.addNode(*new int(i));	// �������в�����
	}
	intList.printList( );	
	int  b=9;
	int* pa=intList.findNode(b);
	if(pa)
		intList.removeNode(*pa);
	else
		cout<<"In main function: No code of value "<<b<<endl;
	intList.removeNode(*new int(5));
	intList.removeNode(*new int(1));
	intList.removeNode(*new int(10));
	intList.printList();

	return 0;
}
