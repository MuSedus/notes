#include<iostream>
using namespace std;

class ST_COM
{
public:
	ST_COM(char *na, unsigned int n, float ma, float en, float ph): num(n),math(ma),english(en),physics(ph)
	{
		strcpy_s(name,na);
		avg=(math+english+physics)/3;
	}
	void show()
	{
		cout<<"Name:"<<name<<"        Number:"<<num<<endl;
		cout<<"Mathematics Score:"<<math<<endl;
		cout<<"English Score     :"<<english<<endl;
		cout<<"Physics Score     :"<<physics<<endl;
	}
protected:
	char name[10];
	unsigned int num;
	float math,english,physics,avg;
};

class EL_DEP:public ST_COM
{
public:
	EL_DEP(char *na,unsigned int n,float ma,float en,float ph,float pe,float el,float d): ST_COM(na,n,ma,en,ph), exchange(pe), elnet(el),dst(d)
	{ 
		avg=((exchange+elnet+dst)/3+ST_COM::avg)/2;
	}
	void show()
	{
		ST_COM::show();
		cout<<"Exchange Score    :"<<exchange<<endl;
		cout<<"Elec_net Score    :"<<elnet<<endl;
		cout<<"Data_struct Scoer :"<<dst<<endl;
		cout<<"Average Score     :"<<avg<<endl;
	}	
private:
	float exchange,elnet,dst;
};

int main()
{
	EL_DEP aStudent("LiQiang",1,71,72,73,81,82,83);
	aStudent.show();

	return 0;
}
