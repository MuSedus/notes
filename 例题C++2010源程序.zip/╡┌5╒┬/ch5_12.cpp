#include <iostream>
using namespace std;

template<class T>
class ClassTemplateTest
{
public:
	ClassTemplateTest(T);
	~ClassTemplateTest( )
	{
		cout<<"call deconstructor function"<<endl;
	}
	T getSize()
	{
		return size;
	}
private:
	T size;
};

template<class T>
ClassTemplateTest<T>::ClassTemplateTest(T n)
{
	size = n;
	cout<<"call constructor function"<<endl;
}

int main( )
{
	ClassTemplateTest<int> object1(5);
	ClassTemplateTest<double> object2(6.66);
	cout<<"---------------------------------"<<endl;
	cout<<"the class name of object1 is: "<<typeid(object1).name()<<endl;
	cout<<"object1.getSize() is "<<object1.getSize()<<endl;
	cout<<"the class name of object2 is: "<<typeid(object2).name()<<endl;
	cout<<"object2.getSize() is "<<object2.getSize()<<endl;
	cout<<"---------------------------------"<<endl;

	return 0;
}
