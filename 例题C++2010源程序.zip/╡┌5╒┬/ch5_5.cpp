#include<iostream>
using namespace std;

class Data
{
public:
	Data(int x)
	{
		Data::x=x;
		cout<<"class Data\n";
	}
private:
	int x;
};

class A
{
public:
	A(int x):d1(x)
	{
		cout<<"class A\n";
	}
private:
	Data d1;
};

class B:public A
{
public:
	B(int x):A(x),d2(x)
	{
		cout<<"class B\n";
	}
private:
	Data d2;
};

class C:public B
{
public:
	C(int x):B(x)
	{	
		cout<<"class C\n";
	}
};

int main()
{
	C object(5);

	return 0;
}