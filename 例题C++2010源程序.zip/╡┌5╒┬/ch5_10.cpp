#include<iostream>
using namespace std;

class Base
{
public:
	Base()
	{	cout<<"This is Base class!\n";	}
};

class Base2
{
public:
	Base2()
	{	cout<<"This is Base2 class!\n";	}
};

class Level1:public Base2,virtual public Base
{
public:
	Level1()
	{	cout<<"This is Level1 class!\n";	}
};

class Level2:public Base2,virtual public Base
{
public:
	Level2()
	{	cout<<"This is Level2 class!\n";	}
};

class TopLevel:public Level1,virtual public Level2
{
public:
	TopLevel()
	{	cout<<"This is TopLevel class!\n";	}
};

int main()
{
	TopLevel topObject;

	return 0;
}
