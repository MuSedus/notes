#include<iostream>
using namespace std;

class Bed
{
public:
	Bed(){	}
	void sleep()
	{	cout <<"sleeping...\n";	}
	void setWeight(int i)
	{	weight = i;	}
protected:
	int weight;
};

class Sofa
{
public:
	Sofa(){  }
	void watchTV()
	{ cout <<"Watching TV.\n"; }
	void setWeight(int i)
	{ weight =i; }
protected:
	int weight;
};

class SleeperSofa :public Bed, public Sofa	// ���ؼ̳�
{
public:
	SleeperSofa(){}
	void foldOut(){ cout <<"Fold out the sofa.\n"; }
};

int main()
{
	SleeperSofa ss;
	ss.watchTV();
	ss.foldOut();
	ss.sleep();
	ss.setWeight(20);		// ���ֶ�����

	return 0;
}
