#include<iostream>
using namespace std;

class Furniture			// ����Ҿ���
{
public:
	Furniture(){}
	void setWeight(int i){ weight =i; }
	int getWeight(){ return weight; }
protected:
	int weight;
};

class Bed : virtual public Furniture	//Furniture����ΪBed��������
{
public:
	Bed(){}
	void sleep(){ cout <<"sleeping...\n"; }
};

class Sofa : virtual public Furniture	// Furniture����ΪSofa��������
{
public:
	Sofa(){}
	void watchTV(){ cout <<"Watching TV.\n"; }
};

class SleeperSofa :public Bed, public Sofa
{
public:
	SleeperSofa():Sofa(),Bed(){}
	void foldOut(){ cout <<"Fold out the sofa.\n"; }
};

int main()
{
	SleeperSofa ss;
	ss.watchTV();
	ss.foldOut();
	ss.sleep();
	ss.setWeight(20);
	cout<<"weight:"<<ss.getWeight()<<endl;

	return 0;
}
