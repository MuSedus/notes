#include<iostream>
using namespace std;

class ST_COM
{
public:
	ST_COM(char *na, unsigned int n, float ma, float en, float ph): num(n),math(ma),english(en),physics(ph)
	{
		strcpy_s(name,na);
	}
protected:
	char name[10];
	unsigned int num;
	float math,english,physics;
};

class EL_DEP:public ST_COM
{
public:
	EL_DEP(char *na,unsigned int n,float ma,float en,float ph,float pe,float el,float d): ST_COM(na,n,ma,en,ph), exchange(pe), elnet(el),dst(d)
	{ }
	void show()
	{
		cout<<"Name:"<<name<<"        Number:"<<num<<endl;
		cout<<"mathics Score:"<<math<<endl;
		cout<<"english Score     :"<<english<<endl;
		cout<<"physics Score     :"<<physics<<endl;
		cout<<"Exchange Score    :"<<exchange<<endl;
		cout<<"Elec_net Score    :"<<elnet<<endl;
		cout<<"Data_structure Score :"<<dst<<endl;
	}
private:
	float exchange,elnet,dst;
};

int main()
{
	EL_DEP aStudent("LiQiang",1,71,72,73,81,82,83);
	aStudent.show();

	return 0;
}
