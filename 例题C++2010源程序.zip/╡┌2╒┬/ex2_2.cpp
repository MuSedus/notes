#include<iostream>
using namespace std;

int main()
{
	int  i=0,&l=i,&k=l;
	i=++l-k;
	cout<<"i="<<i<<endl;

	return 0;
}
