#include<iostream>
using namespace std;

int main()
{
	int *p=new int[3];
	for(int i=0;i<3;i++)
		p[i]=i;
	cout<<"p[0]="<<p[0]<<" ,  p[1]="<<p[1]<<" ,  p[2]="<<p[2]<<"\n";
	
	p[1]++;
	cout<<"p[0]="<<p[0]<<" ,  p[1]="<<p[1]<<" ,  p[2]="<<p[2]<<"\n";

	delete [1]p;
	cout<<"p[0]="<<p[0]<<" ,  p[1]="<<p[1]<<" ,  p[2]="<<p[2]<<"\n";

	return 0;
}
