#include<iostream>
using namespace std;
#define PI 3.1415926535

template<class T>
double Circle_Square(T x)
{
	return x*x*PI;
}

double Circle_Square(long x)
{
	return x*x*PI;
}

int main()
{
	int r1=1;
	double r2=2.0;
	long r3=3;
	cout<<"The first circle square is  "<<Circle_Square(r1)<<endl
		<<"The second circle square is "<<Circle_Square(r2)<<endl
		<<"The third circle square is  "<<Circle_Square(r3)<<endl;

	return 0;
}
