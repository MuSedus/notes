#include<iostream>
using namespace std;
const float PAI=3.14159265;

float square(float r)
{
	return PAI*r*r;
}

float square(float high,length=0)
{
	return high*length;
}

float (*fs)(float,float=0);

int main()
{
	fs=&square;
	cout<<"The circle's square is "<<fs(1.0)<<'\n';

	return 0;
}
