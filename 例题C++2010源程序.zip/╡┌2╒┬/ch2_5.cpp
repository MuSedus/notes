#include <iostream>
using namespace std;

int main()
{
	int num=50;
	int &ref=num;
	ref+=10;
	cout<<"num="<<num<<endl;
	cout<< "ref="<<ref<<endl;
	num+=40;
	cout<< "num="<<num<<endl;
	cout<<"ref="<<ref<<endl;

	return 0;
}
