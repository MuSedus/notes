#include <iostream>
#include <iomanip>
using namespace std;

int main()
{ 
	int a = 10;
	int b = 1000;
	cout <<"a="<<setw(5)<<a<<"\n"; 
	cout <<"b="<<setw(2)<<b<<endl;

	return 0;
}
