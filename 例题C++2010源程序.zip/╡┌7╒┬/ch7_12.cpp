#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	ofstream myf("d:\\myabc.txt"); // Ĭ��ios::out��ios::trunc��ʽ
	char txt[255];
	while (1)
	{
		cin.getline(txt,255);
		if (strlen(txt)==0)
			break;
		myf<<txt<<endl;
	}

	return 0;
}
