#include <iostream>
#include <iomanip>
using namespace std;

int main()
{ 
	double x=66,y=-8.246;
	cout << x<< "\t" << y << endl ;    
	cout << setiosflags(ios::showpos);    // ����ǿ����ʾ����
	cout << x<< "\t" << y << endl ;

	return 0;
}
