#include<iostream>
using namespace std;

class Complex
{
public:
	Complex(float r=0,float i=0)
	{
		real=r;
		imag=i;
	}
	friend ostream & operator <<(ostream &,Complex &);
	friend istream & operator >>(istream &,Complex &);
private:
	float real,imag;
};

ostream & operator <<(ostream &output,Complex &obj)
{
	output<<obj.real;
	if(obj.imag>0) output<< "+";
	if(obj.imag!=0) output<<obj.imag<<"i";
	return output;
}

istream & operator >>(istream &input,Complex &obj)
{
	cout<< "Input the real ,imag of the complex:\n";
	input>>obj.real;
	input>>obj.imag;
	return input;
}

int main( )
{
	Complex c1(2.3f,4.6f), c2(3.6f,2.8f), c3;
	cout<< "the value of c1 is :"<<c1<< "\n";
	cout<< "the value of c2 is :"<<c2<< "\n";
	cin>>c3;
	cout<<"the value of c3 is :"<<c3<< "\n";

	return 0;
}
