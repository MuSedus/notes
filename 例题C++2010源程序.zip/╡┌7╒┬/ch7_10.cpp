#include<iostream>
#include<iomanip>
using namespace std;

class RMB
{
public:
	RMB(double v=0.0)
	{ 
		yuan=unsigned(v);
		jf=unsigned((v-yuan)*100.0+0.5);
	}
	operator double()         // ������ת������
	{
		return yuan+jf/100.0;
	}
	void display(ostream& out)
	{
		out<<yuan<<'.'<<setfill('0')
			<<setw(2)<<jf<<setfill(' ');
	}
protected:
	unsigned int yuan;
	unsigned int jf;
};

ostream& operator << (ostream& ot,RMB& d)
{
	d.display(ot);
	return ot;
}

int main()
{
	RMB rmb(2.3);
	cout<<"Initially rmb="<<rmb<<"\n";   // �������ز������������
	rmb=2.0*rmb;
	cout<<"then rmb="<<rmb<<"\n";

	return 0;
}
